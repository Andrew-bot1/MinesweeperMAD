package com.example.msandrewh;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Toast;






class MineSweeperView extends View {
    private long mouseUP=0; // new to Graphics4
    private long mouseDOWN=0; // new to Graphics4
    boolean longPress = false; // new to Graphics4
    private String tag = "MCU";
    private int touchX;
    private int touchY;
    private final int XBASE=40;
    private final int YBASE=80;
    private final int BW=40;
    private final int BH=40;
    private final int ROWS=10;
    private final int COLS=10;
    private final int NUMBOMBS = 12;
    private final int TILE = 10;
    private final int EMPTY = 11;
    private final int FLAG = 12;
    private final int BOMB = 13;
    private int flags_remaining = NUMBOMBS;
    private boolean game_over = false;
    boolean isbomb[][];
    Context activityContext;
    Canvas canvas;
    private int status[][];
    Bitmap empty_image;
    Bitmap tile_image;
    Bitmap bomb_image;
    Bitmap one_image;
    Bitmap two_image;
    Bitmap three_image;
    Bitmap four_image;
    Bitmap five_image;
    Bitmap six_image;
    Bitmap seven_image;
    Bitmap eight_image;
    Bitmap flag_image;
    String str="";
    private class RowCol {
        public int row;
        public int col;
    }

    private int countNeighboringBombs(int r, int c) {
        int count = 0;
        final int C = COLS - 1;
        final int R = ROWS - 1;
        if ((r > 0) && (c > 0) && (isbomb[r - 1][c - 1])) count++;
        if ((r > 0) && (isbomb[r - 1][c])) count++;
        if ((r > 0) && (c < C) && (isbomb[r - 1][c + 1])) count++;
        if ((c > 0) && (isbomb[r][c - 1])) count++;
        if ((c < C) && (isbomb[r][c + 1])) count++;
        if ((r < R) && (c > 0) && (isbomb[r + 1][c - 1])) count++;
        if ((r < R) && (isbomb[r + 1][c])) count++;
        if ((r < R) && (c < C) && (isbomb[r + 1][c + 1])) count++;
        return count;
    }

    private RowCol getIndex(int x, int y)
    {
        RowCol rc = new RowCol();
        // use x, y and XBASE, YBASE, ROWS, COLS, BW, BH to validate x & y!
        // calculate row and column index given x and y coordinates
        //<snip!>
        rc.row = (y - YBASE) / BH;
        rc.col = (x - XBASE) / BW;

        if (y < YBASE || y > YBASE + ROWS * BH) {
            rc.row = -1;
        }
        if (x < XBASE || x > XBASE + COLS * BW) {
            rc.col = -1;
        }

        print("getIndex: r = " + rc.row + ", c = " + rc.col);
        return rc;
    }

    private void clearBlankNeighbors(int r, int c) {
        status[r][c] = EMPTY;
        int n = countNeighboringBombs(r, c);
        if (n == 0) {
            for (int i = -1; i <= 1; i++) {
                for (int j = -1; j <= 1; j++) {
                    // Clear rows & columns if the tile
                     // has not already been EMPTY
                    if ((r + i < ROWS) && (r + i >= 0) && (c + j < COLS) && (c + j >= 0) &&
                            (status[r + i][c + j] == TILE)) {
                        // Recursive call to clear open tiles.
                        clearBlankNeighbors(r + i, c + j);
                    }
                }
            }
        } else {
            status[r][c] = n;
        }
    }


    @Override
    public boolean onTouchEvent(MotionEvent e)
    {
        if (game_over) {
            print("Stop");

            return true;
        }
        int action = e.getAction();
        touchX = (int) e.getX();
        touchY = (int) e.getY();
        print("onTouchEvent: x = " + touchX + ", y = " + touchY);
        RowCol rc;
        rc = getIndex(touchX, touchY);


        if(action == MotionEvent.ACTION_DOWN) {
            mouseDOWN = System.currentTimeMillis();
        } else if (action == MotionEvent.ACTION_UP) {
            mouseUP = System.currentTimeMillis();
//print("mouseUP = " + mouseUP);
//print("mouseDOWN = " + mouseDOWN);
            // validate row and col? and update status array
            //<snip>
            if (rc.col != -1 && rc.row != -1) {
//                status[rc.col][rc.row] = EMPTY;

                if (mouseUP - mouseDOWN > 200) {
//print("LONG PRESS!");
                    longPress = true;
                    print("long");
                    if (status[rc.col][rc.row] == TILE) {
                        status[rc.col][rc.row] = FLAG;
                    }

                    else if (status[rc.col][rc.row] == FLAG) {
                        status[rc.col][rc.row] = TILE;
                    }

                } else {

                    if (isbomb[rc.col][rc.row] && status[rc.col][rc.row] != FLAG) {
                        status[rc.col][rc.row] = BOMB;
                    }
                    else if (status[rc.col][rc.row] != FLAG) {
                        status[rc.col][rc.row] = EMPTY;

                        int n = countNeighboringBombs(rc.col, rc.row);
                        if (n > 0) {
                            status[rc.col][rc.row] = n;
                        } else {
                            clearBlankNeighbors(rc.col, rc.row);
                        }
                    }


                    longPress = false;
                }
            }
            invalidate();
        }



        //if ()





            invalidate();
        return true;
    }

    private void print(String s)
    {
        Log.i(tag, s);
//Toast.makeText(activityContext, s, 1).show();
    }
    public MineSweeperView(Context context) {
        super(context);
        activityContext = context;
        print("MineSweeperView constructor:");
        isbomb = new boolean[ROWS][COLS];
        status = new int[ROWS][COLS];
        for (int i=0; i<ROWS; i++) {
            for (int j=0; j<COLS; j++) {
                status[i][j] = TILE;
            }
        }

        int count = 0;
        while (count < NUMBOMBS) {
            int r = (int) (ROWS * Math.random());
            int c = (int) (COLS * Math.random());
            if (!isbomb[r][c]) {
                print("bomb placed at [" + r + "][" + c + "]");
                isbomb[r][c] = true;
                count++;
            }
        }

       // status[0][0] = EMPTY;

        empty_image = BitmapFactory.decodeResource(getResources(), R.drawable.empty);
        tile_image = BitmapFactory.decodeResource(getResources(), R.drawable.tile);
        bomb_image  = BitmapFactory.decodeResource(getResources(), R.drawable.bomb);

        one_image = BitmapFactory.decodeResource(getResources(), R.drawable.bluenum1);
        two_image  = BitmapFactory.decodeResource(getResources(), R.drawable.bluenum2);
        three_image  = BitmapFactory.decodeResource(getResources(), R.drawable.bluenum3);
        four_image  = BitmapFactory.decodeResource(getResources(), R.drawable.bluenum4);
        five_image  = BitmapFactory.decodeResource(getResources(), R.drawable.bluenum5);
        six_image  = BitmapFactory.decodeResource(getResources(), R.drawable.bluenum6);
        seven_image  = BitmapFactory.decodeResource(getResources(), R.drawable.bluenum7);
        eight_image  = BitmapFactory.decodeResource(getResources(), R.drawable.bluenum8);
        flag_image = BitmapFactory.decodeResource(getResources(), R.drawable.flag);
    }
    private void drawbmp(Bitmap bm, int x, int y, int w, int h)
    {
        canvas.drawBitmap(bm, null, new Rect(x,y,x+w-1, y+h-1), null);
    }
    @Override
    public void onDraw(Canvas canvas) {
        Paint fg = new Paint();
        int w = getWidth();
        int h = getHeight();
        this.canvas = canvas;
        print("onDraw: w = " + w + ", h = " + h);
        canvas.drawColor(Color.WHITE);
        fg.setColor(Color.BLACK);

        int tiles = 0;
        int flags = 0;

        for (int i = 0; i < status.length; i++) {
            for (int j = 0; j < status[i].length; j++) {
                if (status[i][j] == FLAG) {
                    flags ++;
                    drawbmp(flag_image, i * BW +XBASE, j * BH +YBASE, 40, 40);
                }
                else if (status[i][j] == TILE) {
                    tiles ++;
                    drawbmp(tile_image, i * BW +XBASE, j * BH +YBASE, 40, 40);
                }
                else if (isbomb[i][j]) {
                    drawbmp(bomb_image, i * BW + XBASE, j * BH + YBASE, 40, 40);
                    Toast.makeText(this.getContext(), "Game Over", Toast.LENGTH_LONG).show();
                    game_over = true;

                }
                else
                {
                    //int count = countNeighboringBombs(i, j);
                    switch(countNeighboringBombs(i,j)) {
                        case 1:
                            drawbmp(one_image, i * BW + XBASE, j * BH + YBASE, 40, 40);
                            break;
                        case 2:
                            drawbmp(two_image, i * BW + XBASE, j * BH + YBASE, 40, 40);
                            break;
                        case 3:
                            drawbmp(three_image, i * BW + XBASE, j * BH + YBASE, 40, 40);
                            break;
                        case 4:
                            drawbmp(four_image, i * BW + XBASE, j * BH + YBASE, 40, 40);
                            break;
                        case 5:
                            drawbmp(five_image, i * BW + XBASE, j * BH + YBASE, 40, 40);
                            break;
                        case 6:
                            drawbmp(six_image, i * BW + XBASE, j * BH + YBASE, 40, 40);
                            break;
                        case 7:
                            drawbmp(seven_image, i * BW + XBASE, j * BH + YBASE, 40, 40);
                            break;
                        case 8:
                            drawbmp(eight_image, i * BW + XBASE, j * BH + YBASE, 40, 40);
                            break;
                        case 0:
                            drawbmp(empty_image, i * BW +XBASE, j * BH +YBASE, 40, 40);
                            break;
                    }
            }


        }}

        if (tiles == 0 && flags == NUMBOMBS) {
            Toast.makeText(this.getContext(), "You Won!", Toast.LENGTH_LONG).show();
            game_over = true;
        }


        canvas.drawLine(XBASE-2, YBASE-2,(XBASE+COLS*BW)+2,YBASE-2,fg);
        canvas.drawLine(XBASE-2, (YBASE+ROWS*BH)+2,(XBASE+COLS*BW)+2,(YBASE+ROWS*BH)+2,fg);

        canvas.drawLine(XBASE-2, YBASE-2,XBASE-2,(YBASE+ROWS*BH)+2,fg);
        canvas.drawLine((XBASE+COLS*BW)+2, YBASE-2,(XBASE+COLS*BW)+2,(YBASE+ROWS*BH)+2,fg);

// <SNIP!>
    }
}



public class MainActivity extends AppCompatActivity {
    private String tag = "MCU";
    MineSweeperView mineSweeperView;
    private void print(String s)
    {
        Log.i(tag, s);
//Toast.makeText(this, s, 1).show();
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
      //  setContentView(R.layout.activity_main);

        print("onCreate:");
        Toast.makeText(this, "MineSweeper", Toast.LENGTH_LONG).show();
        mineSweeperView = new MineSweeperView(this);
        setContentView(mineSweeperView);




    }
}